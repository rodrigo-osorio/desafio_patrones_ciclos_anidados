# desafio 2

# Escribir un  programa llamado patrones.rb  
# con  métodos que  reciban la  cantidad de 
# lineas y muestren por pantalla los siguientes patrones de *: 

# a) Letra O

def letra_o(num)
    
    line = "*"*num
    
    for i in 1..num do
    
        if i==1
            print line
        elsif i==num
            print "\n"+line+"\n"
        else
            print "\n*"+"\s"*(num-2)+"*"
        end
    end
    print "\s"
end

#b) Letra I

def letra_i(num)

    num.times do
        print "*"
    end
    
    puts "\n"
    (num-2).times do
        print "\s\s"+"*"+"\s\s\n"
    end

    num.times do
        print "*"
    end
    puts "\n"
end

#c) Letra Z

def letra_z(num)

    print "*"*num + "\n"

    (num-2).downto(1) do |i|
        
        print "\s"*i + "*\n"
    
    end
    
    print "*"*num
    print "\n"
end

#d) Letra X

def letra_x(num)
    
    i = (num-3)
    j=0  

    while (i!=0) do
        
        print "\s"*j + "*" + "\s"*(2*i-1)+ "*" + "\s"*j +"\n" #parte de arriba de la X
        j+=1
        i-=1
    end

    print "\s"*((num-1)/2) + "*" + "\s"*((num-1)/2) + "\n" # parte del centro de la X
    
    i=0
    j=1     
    until (i==(num-3)) do
        print "\s"*j + "*" + "\s"*(2*i+1)+ "*" + "\s"*j+"\n" #parte de abajo de la x
        j-=1
        i+=1
    end
end

#e) Numero 0

def numero_cero(num)

    print "*" * num + "\n" #parte de arriba del cero
    
    i=0
    until(i==(num-2)) do
        print "*" + "\s"*i + "*" + "\s"*(2-i) + "*" + "\n" #diagonal y laterales
        i+=1
    end

    print "*" * num #parte de abajo del cero
    print "\n"
end

#f) navidad

def navidad(num)
   
    #copa del arbol
    i=0

    while (i != (num-1)) do 
        
        j=0
        print "\s"*(((num+1)/2)-i)
        until (j == (2*i+1))
        
            if(j%2==0)
                print "*"
            else
                print "\s" 
            end
            j+=1
        end
        puts "\n"
        i+=1
    end

    #tronco del arbol
    for i in 0...(num-3) do
        puts "\s" *((num+1)/2) + "*"
    end

    #base del arbol
    for i in 0..(num+1) do
        if (i%2==0)   
            print "\s"   
        else 
            print "*"
        end
    end
    print "\s"
end

puts letra_o(5)
puts letra_i(5)
puts letra_z(5)
puts letra_x(5)
puts numero_cero(5)
puts navidad(5)
