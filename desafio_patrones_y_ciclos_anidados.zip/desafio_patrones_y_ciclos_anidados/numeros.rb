# desafio 1

# Escribir un programa llamado numeros.rb, que reciba por linea de comandos la cantidad de lineas, 
# y dibuje el siguiente patrón: ruby numeros.rb 5 --> 1 12 123 1234 12345

num = ARGV[0].to_i

for i in (1..num) do
    
    num_line = ""
    next_number ="1"
    
    i.times do 
        num_line += next_number
        next_number = next_number.next
    end
    print num_line + " "
end

